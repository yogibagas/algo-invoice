<footer class="footer">
    <div class="container-fluid">
        <ul class="nav">
            <li class="nav-item">
                <a href="https://creative-tim.com" target="blank" class="nav-link">
                    <?php echo e(__('Our Website')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a href="https://updivision.com" target="blank" class="nav-link">
                    <?php echo e(__('Instagram')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <?php echo e(__('Facebook')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <?php echo e(__('Youtube')); ?>

                </a>
            </li>
        </ul>
        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> Allright Reserved
        </div>
    </div>
</footer>
<?php /**PATH /Users/yogibagasd/algoseabiz/algoapp/resources/views/layouts/footer.blade.php ENDPATH**/ ?>