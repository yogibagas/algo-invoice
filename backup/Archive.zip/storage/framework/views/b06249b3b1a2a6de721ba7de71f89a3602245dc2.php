<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-sm-8">
                            <h4 class="card-title">Bank</h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('bank.create')); ?>" class="btn btn-sm btn-primary">Add Bank</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">

                    <div class="table-responsive min-vh-100">
                        <table class="table tablesorter " id="">
                            <thead class=" text-primary">
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Bank Name</th>
                                    <th scope="col">Bank Number</th>
                                    <th scope="col">Holder Name</th>
                                    <th scope="col">Swift Code</th>
                                    <th scope="col">Bank Code</th>
                                    <th scope="col">Create Date</th>
                                    <th scope="col">Last Update</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td class="text-capitalize"><?php echo e($m->bank_name); ?> <small class="text-uppercase">(<?php echo e($m->shortname); ?>)<small></td>
                                        <td><?php echo e($m->bank_number); ?></td>
                                        <td  class="text-capitalize"><?php echo e($m->bank_holder_name); ?></td>
                                        <td class="text-uppercase"><?php echo e($m->bank_swift); ?></td>
                                        <td><?php echo e($m->bank_code); ?></td>
                                        <td><?php echo e($m->created_at->format('d F Y H:i:s')); ?></td>
                                        <td><?php echo e($m->updated_at->format('d F Y H:i:s')); ?></td>
                                        <td class="text-right">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                    <a class="dropdown-item" href="<?php echo e(route('bank.edit',$m->id)); ?>">Edit</a>
                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <?php echo e($banks->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'bank', 'titlePage' => __('Banks'),'pageSlug' => __('bank')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yogibagasd/algoseabiz/algoapp/resources/views/bank/index.blade.php ENDPATH**/ ?>