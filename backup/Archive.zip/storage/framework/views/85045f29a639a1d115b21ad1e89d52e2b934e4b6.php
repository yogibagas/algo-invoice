  
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
      <div class="col-md-8">
        <form method="post" enctype="multipart/form-data" action="<?php echo e($model->exists ? route('bank.update',$model->id):route('bank.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field($model->exists ? "PUT" : 'POST'); ?>
          <div class="card ">
            <div class="card-header">
              <h4 class="card-title">Add Item</h4>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success mt-3">
                    <?php echo e($message); ?>

                </div>
                <?php endif; ?>

                <?php if($message = Session::get('failed')): ?>
                <div class="alert alert-danger mt-3">
                    <?php echo e($message); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12 text-right mb-4">
                    <a href="<?php echo e(route('bank.index')); ?>" class="btn btn-sm btn-primary">Back to list</a>
                </div>
              </div>
              <div class="row">
                  <div class="col-md-4">
                    <label class="col-sm-12">Bank Name</label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <input class="form-control" name="bank_name" id="input-bank_name" placeholder="ex: Bank Central Asia"  type="text" value="<?php echo e($model ?  $model->bank_name : old('bank_name')); ?>" required="true" 
                        aria-required="true">
                    </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <label class="col-sm-12">Bank Number</label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <input class="form-control" name="bank_number" id="input-bank_number" type="text" value="<?php echo e($model ? $model->bank_number : old('bank_number')); ?>" required="true"  required="true" aria-required="true">
                    </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <label class="col-sm-12">Swift Code </label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <input class="form-control" name="bank_swift" id="input-bank_swift" type="text"  value="<?php echo e($model ? $model->bank_swift : old('bank_swift')); ?>" required="true"  required="true" aria-required="true">
                    </div>
                    </div>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label for="" class="col-md-12">Bank Account Name</label>
                  <div class="col-sm-12">
                    <div class="form-group">
                      <input type="text" name="bank_holder_name" id="input-bank_holder_name" placeholder="ex: John Doe" class="form-control" value="<?php echo e($model ? $model->bank_holder_name : old('bank_holder_name')); ?>" required>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-4">
                  <label class="col-sm-12">Bank Code</label>
                  <div class="col-sm-12">
                  <div class="form-group">
                      <input class="form-control" name="bank_code" id="input-bank_code" type="text" placeholder="ex:014" value="<?php echo e($model ? $model->bank_code : old('bank_code')); ?>" required="true"  required="true" aria-required="true">
                  </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <label class="col-sm-12">Bank Shortname</label>
                  <div class="col-sm-12">
                  <div class="form-group">
                      <input class="form-control" name="shortname" id="input-shortname" type="text" placeholder="ex: BCA" value="<?php echo e($model ?  $model->shortname : old('shortname')); ?>" required="true"  required="true" aria-required="true">
                  </div>
                  </div>
                </div>

                <div class="col-md-4">
                  <label class="col-md-12">Status</label>
                  <div class="col-sm-12">
                    <select name="status" class="form-control">
                      <option value="active" <?php echo e($model->status == "active" || !$model->status ? "selected" : false); ?>>Active</option>
                      <option value="deactive" <?php echo e($model->status == "deactive" ? "selected" : false); ?>>Deactive</option>
                    </select>
                  </div>
                </div>
            </div>
            </div>
            <div class="card-footer text-right">
              <button type="submit" class="btn"><?php echo e($model->exists ? "Update Data" : "Add Item"); ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'BankForm', 'titlePage' => __('Bank'),'pageSlug' => __('bank')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yogibagasd/algoseabiz/algoapp/resources/views/bank/form.blade.php ENDPATH**/ ?>