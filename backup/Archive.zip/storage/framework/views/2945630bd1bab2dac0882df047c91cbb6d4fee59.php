  
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <form method="post" enctype="multipart/form-data" action="<?php echo e($model->exists ? route('invoice.update',$model->id):route('invoice.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field($model->exists ? "PUT" : 'POST'); ?>
          <div class="card ">
            <div class="card-header">
              <h4 class="card-title">New Invoice </h4>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success mt-3">
                    <?php echo e($message); ?>

                </div>
                <?php endif; ?>

                <?php if($message = Session::get('failed')): ?>
                <div class="alert alert-danger mt-3">
                    <?php echo e($message); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12 text-right mb-4">
                    <a href="<?php echo e(route('invoice.index')); ?>" class="btn btn-sm btn-primary">Back to list</a>
                </div>
              </div>
              <div class="row">
                  <div class="col-md-4">
                    <label class="col-sm-12">Select Client</label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <select class="form-control text-warning" name="client_id" id="select-client" readonly="">
                          <?php if($model->exists): ?>
                          <option value="<?php echo e($model->client_id); ?>" <?php echo e($model->client_id == $model->client_id ? "selected":false); ?>><?php echo e($model->client->name); ?> - <?php echo e($model->client->pic_name); ?></option>
                          <?php else: ?>
                          <option value="">-- Choose client here</option>
                            <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>" <?php echo e($c->id == $model->client_id ? "selected":false); ?>><?php echo e($c->name); ?> - <?php echo e($c->pic_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </select>
                    </div>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <label class="col-sm-12">Invoice No</label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <input class="form-control text-warning" name="no_inv" readonly id="input-no_inv" type="text" placeholder="" value="<?php echo e($model ? $model->no_inv : old('no_inv')); ?>" required="true"  required="true" aria-required="true">
                    </div>
                    </div>
                  </div>
                  <div class="col-md-3">
                    <label class="col-sm-12">Status </label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <select class="form-control" name="status" id="input-status">
                          <option value="ONHOLD" <?php echo e($model->status == "ONHOLD"? "selected":false); ?>>ONHOLD</option>
                          <option value="PAID" <?php echo e($model->status =="PAID" ? "selected" : false); ?>>PAID</option>
                        </select>
                    </div>
                    </div>
                  </div>

                  <div class="col-md-3">
                    <label class="col-sm-12">Due Date</label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <input type="date" name="due_date" class="form-control" value="<?php echo e($model->exists ? \Carbon\Carbon::parse($model->due_date)->format('Y-m-d') : date('Y-m-d', strtotime('+7 days'))); ?>">
                        
                    </div>
                    </div>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="card">
                    <div class="card-header">Item List
                    </div>
                    <div id="item-loop-wrapper">
                    <?php if(!$model->exists): ?>
                    <div class="card-body">
                      <div class="card loop-wrapper">
                        <div class="card-header">
                          <div class="row">
                            <span class="col-8">Invoice Item </span>
                          </div>
                        </div>
                        <div class="card-body">
                          <div class="row">
                            <div class="col-2 col-md-3">
                              <div class="form-group">
                                <label for="">Item Name*</label>
                                <input type="text" class="form-control" name="item_name[]" value="">
                              </div>
                            </div>
                            <div class="col-2 col-md-2">
                              <div class="form-group">
                                <label for="">Type*</label>
                                <select class="form-control" name="item_qty_type[]">
                                  <option value="FIXED" > Fixed Price</option>
                                  <option value="HOURLY" >Hourly Rates</option>
                                </select>
                              </div>
                            </div>
                            <div class="col-2 col-md-1">
                              <div class="form-group">
                                <label for="">Quantity*</label>
                                <input type="number" name="item_qty[]" value="" onkeyup="calcPrice(this)" onload="calcPrice(this)" class="form-control qty">
                              </div>
                            </div>
                            <div class="col-2 col-md-1">
                              <div class="form-group">
                                <label for="">Item Price*</label>
                                <input type="number" name="item_price[]" value="" onkeyup="calcPrice(this)" onload="calcPrice(this)" class="form-control price">
                              </div>
                            </div>
                            <div class="col-2 col-md-3">
                              <div class="form-group">
                                <label for="">Item Note</label>
                                <input type="text" value="" name="item_note[]" class="form-control">
                              </div>
                            </div>
                            <div class="col-2 col-md-2">
                              <label>Adjustment/Discount(%)</label>
                              <input type="number" name="item_adjustment[]" value="" onkeyup="calcPrice(this)" onload="calcPrice(this)" class="form-control adjustment">
                            </div>
                          </div>
                        </div>
                        <div class="card-footer text-right text-white font-weight-bold">Total : <span class="totalprice"> </span> </div>
                      </div>    
                  </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $model->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-body" >
                        <div class="card loop-wrapper" id="loop-wrapper-<?php echo e($loop->iteration); ?>">
                          <div class="card-header">
                            <div class="row">
                              <span class="col-8">Invoice Item </span>
                            <input type="hidden" name="item_id[]" value="<?php echo e($item->id); ?>">
                              <?php if($loop->iteration > 1 ): ?>
                              <span class="col-4 text-right">
                                <a href="#" class="btn-sm btn-danger remove-item" onclick="removeItem(<?php echo e($loop->iteration); ?>)">X</a>
                              </span>
                              <?php endif; ?>
                            </div>
                          </div>
                          <div class="card-body">
                            <div class="row">
                              <div class="col-2 col-md-3">
                                <div class="form-group">
                                  <label for="">Item Name*</label>
                                  <input type="text" class="form-control" name="item_name[]" value="<?php echo e($model->exists ? $item->item_name : ""); ?>">
                                </div>
                              </div>
                              <div class="col-2 col-md-2">
                                <div class="form-group">
                                  <label for="">Type*</label>
                                  <select class="form-control" name="item_qty_type[]">
                                    <option value="FIXED" <?php echo e($item->qty_type == "FIXED" ? "Selected":false); ?>> Fixed Price</option>
                                    <option value="HOURLY" <?php echo e($item->qty_type == "HOURLY" ? "Selected":false); ?>>Hourly Rates</option>
                                  </select>
                                </div>
                              </div>
                              <div class="col-2 col-md-1">
                                <div class="form-group">
                                  <label for="">Quantity*</label>
                                  <input type="number" name="item_qty[]" value="<?php echo e($model->exists ? $item->qty : 1); ?>" onkeyup="calcPrice(this)" onload="calcPrice(this)" class="form-control qty">
                                </div>
                              </div>
                              <div class="col-2 col-md-1">
                                <div class="form-group">
                                  <label for="">Item Price*</label>
                                  <input type="number" name="item_price[]" value="<?php echo e($model->exists ? $item->price : 0); ?>" onkeyup="calcPrice(this)" onload="calcPrice(this)" class="form-control price">
                                </div>
                              </div>
                              <div class="col-2 col-md-3">
                                <div class="form-group">
                                  <label for="">Item Note</label>
                                  <input type="text" value="<?php echo e($item->item_note); ?>" name="item_note[]" class="form-control">
                                </div>
                              </div>
                              <div class="col-2 col-md-2">
                                <label>Adjustment/Discount(%)</label>
                                <input type="number" name="item_adjustment[]" value="<?php echo e($model->exists ? $item->adjustment/($item->price*$item->qty)*100 : 0); ?>" onkeyup="calcPrice(this)" onload="calcPrice(this)" class="form-control adjustment">
                              </div>
                            </div>
                          </div>
                          <div class="card-footer text-right text-white font-weight-bold">Total : <span class="totalprice"> <?php echo e($model->exists ? $item->total:0); ?> </span> </div>
                        </div>    
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                    <div class="card-footer items-align-center ">
                      <div class="row">
                        <div class="col-12">
                          <div class="alert alert-danger">
                            Item Notes if the item type is <strong>HOURLY RATE</strong>*
                            <ul>
                              <li>Please put total <b>HOURS</b> Spend in the quantity</li>
                              <li>Please put item price with your hourly rate</li>
                            </ul>
                          </div>
                        </div>
                        <div class="col-12 text-right">
                          <a href="#" id="add-item" class="btn">+ More Item</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer text-right">
              <div class="col-md-12">
                <div class="row ">
                  <div class="form-group">
                    <h4 for="" class="d-inline-block font-weight-bold text-warning font-size-bg">Total Invoice: </h4>
                    <input type="text" class="bg-transparent border-0 ml-2 d-inline-block font-weight-bold text-white readonly invoice_total text-left" value="<?php echo e($model->total ? $model->total : 0); ?>" readonly name="total" id="input-Gtotal" >
                  </div>
                </div>
              </div>
              <button type="submit" class="btn"><?php echo e($model->exists ? "Update Invoice" : "Save Invoice"); ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
  var i = $('.loop-wrapper').length;

  $(document).ready(function(e){

    $("#add-item").on('click',function(){
      event.preventDefault();
    i++;
      $("#item-loop-wrapper").append(`
                        <div class="card loop-wrapper" id="loop-wrapper-`+i+`">
                          <div class="card-header">
                            <div class="row">
                              <span class="col-8">Invoice Item </span>
                              <span class="col-4 text-right">
                                <a href="#" class="btn-sm btn-danger remove-item" onclick="removeItem(`+i+`)">X</a>
                              </span>
                            </div>
                          </div>
                          <div class="card-body">
                            <div class="row">
                              <div class="col-2 col-md-3">
                                <div class="form-group">
                                  <label for="">Item Name*</label>
                                  <input type="text" class="form-control" name="item_name[]">
                                </div>
                              </div>
                              <div class="col-2 col-md-2">
                                <div class="form-group">
                                  <label for="">Type*</label>
                                  <select class="form-control" name="item_qty_type[]">
                                    <option value="FIXED"> Fixed Price</option>
                                    <option value="HOURLY">Hourly Rates</option>
                                  </select>
                                </div>
                              </div>
                              <div class="col-2 col-md-1">
                                <div class="form-group">
                                  <label for="">Quantity*</label>
                                  <input type="number" value="1" name="item_qty[]" onkeyup="calcPrice(this)" class="form-control qty">
                                </div>
                              </div>
                              <div class="col-2 col-md-1">
                                <div class="form-group">
                                  <label for="">Item Price*</label>
                                  <input type="number" value="0" name="item_price[]" onkeyup="calcPrice(this)" class="form-control price">
                                </div>
                              </div>
                              <div class="col-2 col-md-3">
                                <div class="form-group">
                                  <label for="">Item Note</label>
                                  <input type="text" value="" name="item_note[]" class="form-control">
                                </div>
                              </div>
                              <div class="col-2 col-md-2">
                                <label>Adjustment/Discount(%)</label>
                                <input type="number" name="item_adjustment[]" value="0" onkeyup="calcPrice(this)" class="form-control adjustment">
                              </div>
                            </div>
                          <div class="card-footer text-right text-white font-weight-bold">Total : <span class="totalprice"></span> </div>
                          </div>
                        </div>`)

    });

  //generate invoice no
    $("#select-client").on('change',function(){
      var clientID = $(this).children("option:selected").val();
      $.ajax({
        type: "GET",
        url: clientID+"/generate",
        success: function(res){
          console.log(res);
          $("#input-no_inv").val(res)
        }

      });
    });
  });
  
  function removeItem(i){
    event.preventDefault();
    if(confirm('are you sure want to delete this item?')){
      $('#loop-wrapper-'+i).remove();
      i--;
      // console.log('#loop-wrapper-'+i);
      }
      return i;
  }
  function calcPrice(item){
    var wrapper = $(item).closest('.loop-wrapper');
    var qty = wrapper.find('.qty').val();
    var price = wrapper.find('.price').val();
    var adjustment = wrapper.find('.adjustment').val();
    var subTotal = qty*price;
    var grandTotal = subTotal - (adjustment/100*subTotal);

    wrapper.find('.totalprice').html(grandTotal)
    $(".invoice_total").val(totalInvoice());
    return true;
  }

  function totalInvoice(){
    var totalPerRow = 0;
    var adjustmentPerRow =0;
    var grandTotalPerRow =0;

    var adjustment=0;
    var grandTotal =0;
    $('.loop-wrapper').each( function() {
      totalPerRow = $(this).find(".qty").val() * $(this).find(".price").val();
      adjustmentPerRow =($(this).find(".adjustment").val()/100) * totalPerRow;
      grandTotalPerRow = totalPerRow - adjustmentPerRow;

      grandTotal += grandTotalPerRow;
    });
    // console.log(total,adjustment);
    return grandTotal;
  }

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'InvoiceForm', 'titlePage' => __('Invoice'),'pageSlug' => __('invoices')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yogibagasd/algoseabiz/algoapp/resources/views/invoice/form.blade.php ENDPATH**/ ?>