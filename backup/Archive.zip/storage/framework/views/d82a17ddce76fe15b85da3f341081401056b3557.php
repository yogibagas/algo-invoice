<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-sm-8">
                            <h4 class="card-title">Invoices</h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('invoice.create')); ?>" class="btn btn-sm btn-primary">Add invoice</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table class="table tablesorter " id="">
                            <thead class=" text-primary">
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Invoice No</th>
                                    <th scope="col">Client</th>
                                    <th scope="col">Total Item</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Due Date</th>
                                    <th scope="col">Created At</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($c->no_inv); ?></td>
                                        <td><?php echo e($c->client->name); ?></td>
                                        
                                        <td><?php echo e($c->items_count); ?> Item<?php echo e($c->items_count > 1 ? "s":false); ?></td>
                                        <td><?php echo e(number_format($c->total,0,0,".")); ?></td>
                                        <td> <span class="<?php echo e($c->status == "ONHOLD" ? "text-danger" : "text-info"); ?>"><?php echo e($c->status); ?></span></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($c->due_date)->format('d F Y')); ?></td>
                                        <td><?php echo e($c->created_at->format('d F Y H:i:s')); ?> <br> 
                                            <small>last update: <?php echo e($c->updated_at->format('d F Y H:i:s')); ?></small>
                                        </td>
                                        <td class="text-right">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                    <a class="dropdown-item" href="<?php echo e(route('invoice.edit',$c->id)); ?>">Edit</a>
                                                    <a class="dropdown-item" href="<?php echo e(route('invoice.payment',strtolower($c->no_inv))); ?>" target="_blank">Visit Link Payment</a>
                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <?php echo e($model->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Invoice', 'titlePage' => __('Invoice'),'pageSlug' => __('invoices')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yogibagasd/algoseabiz/algoapp/resources/views/invoice/index.blade.php ENDPATH**/ ?>