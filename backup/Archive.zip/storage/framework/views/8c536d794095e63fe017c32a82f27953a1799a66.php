<div class="sidebar">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="#" class="simple-text logo-mini"><?php echo e(__(' ')); ?></a>
            <a href="#" class="simple-text logo-normal"><?php echo e(__('Algo Sea Biz')); ?></a>
        </div>
        <ul class="nav">
            <li <?php if($pageSlug == 'dashboard'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li <?php if($pageSlug == 'clients'): ?> class="active " <?php endif; ?>>
                <a data-toggle="collapse" href="#clients" aria-expanded="true">
                    <i class="fa fa-user"></i>
                    <span class="nav-link-text"><?php echo e(__('Clients')); ?></span>
                    <b class="caret mt-1"></b>
                </a>
            </li>
            <div class="collapse <?php echo e($pageSlug == 'clients' ? 'show' : false); ?>" id="clients">
                <ul class="nav pl-4">
                    <li <?php if(isset($activePage)): ?> class="<?php echo e($activePage == 'ClientIndex' ? 'active' : false); ?>" <?php endif; ?>>

                        <a href="<?php echo e(route('client.index')); ?>">
                            <i class="tim-icons icon-single-02"></i>
                            <p><?php echo e(__('Client List')); ?></p>
                        </a>
                    </li>
                    <li <?php if(isset($activePage)): ?> class="<?php echo e($activePage == 'ClientForm' ? 'active' : false); ?>" <?php endif; ?>>
                        <a href="<?php echo e(route('client.create')); ?>">
                            <i class="tim-icons icon-simple-add"></i>
                            <p><?php echo e(__('Add New Client')); ?></p>
                        </a>
                    </li>
                </ul>
            </div>

            <li <?php if($pageSlug == 'organizations'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('organization.edit',1)); ?>">
                    <i class="tim-icons icon-settings-gear-63"></i>
                    <p><?php echo e(__('Organization')); ?></p>
                </a>
            </li>
            <li <?php if($pageSlug == 'bank'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('bank.index')); ?>">
                    <i class="tim-icons icon-bank"></i>
                    <p><?php echo e(__('Bank List')); ?></p>
                </a>
            </li>

            <li <?php if($pageSlug == 'invoices'): ?> class="active " <?php endif; ?>>
                <a href="<?php echo e(route('invoice.index')); ?>">
                    <i class="tim-icons icon-paper"></i>
                    <p><?php echo e(__('Invoice')); ?></p>
                </a>
            </li>
            
        </ul>
    </div>
</div>
<?php /**PATH /Users/yogibagasd/algoseabiz/algoapp/resources/views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>