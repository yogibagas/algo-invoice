<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="title"><?php echo e(__('Edit Organization Profile')); ?></h5>
                </div>
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('organization.update', $organization->id)); ?>" autocomplete="off">
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success mt-3">
                                <?php echo e($message); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($message = Session::get('failed')): ?>
                            <div class="alert alert-danger mt-3">
                                <?php echo e($message); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <div class="row mb-2">
                            <label class="col-sm-12 col-form-label">Logo</label>
                            <div class="col-sm-3">
                                <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                    <div>
                                        <input class="btn btn-file text-left" type="file" name="logo" id="input-picture">
                                    </div>

                                    <div class="fileinput-new d-none">
                                        <img src="#"
                                            class="img-thumbnail" alt="...">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label><?php echo e(__('Organization/Company Name')); ?></label>
                            <input type="text" name="company_name" class="form-control" placeholder="<?php echo e(__('Name')); ?>"
                                value="<?php echo e(old('name', $organization->company_name)); ?>">
                        </div>

                        <div class="form-group">
                            <label><?php echo e(__('Phone')); ?></label>
                            <input type="text" name="phone_number" class="form-control" placeholder="<?php echo e(__('Phone')); ?>"
                                value="<?php echo e(old('phone', $organization->phone_number)); ?>">
                        </div>

                        <div class="form-group">
                            <label><?php echo e(__('Tax ID')); ?></label>
                            <input type="text" name="tax_id" class="form-control" placeholder="<?php echo e(__('Name')); ?>"
                                value="<?php echo e(old('tax_id', $organization->tax_id)); ?>">
                        </div>

                        <div class="form-group">
                            <label><?php echo __('Thankyou Message <small>(put your message for the invoice)</small>'); ?></label>
                            <textarea name="thankyou_message" class="form-control" placeholder="<?php echo e(__('Ex: Thankyou for trusting us as your partner...')); ?>"
                            ><?php echo e(old('thankyou_message', $organization->thankyou_message)); ?></textarea>
                        </div>

                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-fill btn-primary"><?php echo e(__('Save')); ?></button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-user">
                <div class="card-body">
                    <p class="card-text">
                    <div class="author">
                        <div class="block block-one"></div>
                        <div class="block block-two"></div>
                        <div class="block block-three"></div>
                        <div class="block block-four"></div>
                        <a href="#">
                            <img class="img-fluid img-thumbnail mb-3" src="<?php echo e(asset('organization')); ?>/<?php echo e($organization->logo ? $organization->logo : 'logo.png'); ?>" alt="" width="250px">
                            <h3 class="title"><?php echo e($organization->company_name); ?></h3>
                        </a>
                    </div>
                    </p>
                    <div class="card-description text-center">
                        <?php echo e($organization->phone_number ." - ". $organization->tax_id); ?><br>
                    </div>
                </div>
                <div class="card-footer">
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Organization', 'titlePage' => __('Organization'),'pageSlug' => __('organizations')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yogibagasd/algoseabiz/algoapp/resources/views/organizations/index.blade.php ENDPATH**/ ?>