  
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
      <div class="col-md-8">
        <form method="post" enctype="multipart/form-data" action="<?php echo e($client->exists ? route('client.update',$client->id):route('client.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field($client->exists ? "PUT" : 'POST'); ?>
          <div class="card ">
            <div class="card-header">
              <h4 class="card-title">Add Item</h4>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success mt-3">
                    <?php echo e($message); ?>

                </div>
                <?php endif; ?>

                <?php if($message = Session::get('failed')): ?>
                <div class="alert alert-danger mt-3">
                    <?php echo e($message); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12 text-right mb-4">
                    <a href="<?php echo e(route('client.index')); ?>" class="btn btn-sm btn-primary">Back to list</a>
                </div>
              </div>
              <div class="row">
                  <div class="col-md-4">
                    <label class="col-sm-12">Name</label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <input class="form-control" name="name" id="input-name" type="text" placeholder="Name" value="<?php echo e($client ?  $client->name : old('name')); ?>" required="true" 
                        aria-required="true">
                    </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <label class="col-sm-12">Pic Name</label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <input class="form-control" name="pic_name" id="input-pic" type="text" placeholder="Pic Name" value="<?php echo e($client ? $client->pic_name : old('pic_name')); ?>" required="true"  required="true" aria-required="true">
                    </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <label class="col-sm-12">Client Code <small>(used for invoice purpose)</small></label>
                    <div class="col-sm-12">
                    <div class="form-group">
                        <input class="form-control" name="code" id="input-code" type="text" placeholder="Client Code" value="<?php echo e($client ? $client->code : old('code')); ?>" required="true"  required="true" aria-required="true">
                    </div>
                    </div>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-4">
                  <label class="col-sm-12">Address</label>
                  <div class="col-sm-12">
                  <div class="form-group">
                      <input class="form-control" name="address" id="input-address" type="text" placeholder="Address" value="<?php echo e($client ? $client->address : old('address')); ?>" required="true"  required="true" aria-required="true">
                  </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <label class="col-sm-12">Phone</label>
                  <div class="col-sm-12">
                  <div class="form-group">
                      <input class="form-control" name="phone" id="input-phone" type="text" placeholder="Phone" value="<?php echo e($client ?  $client->phone : old('phone')); ?>" required="true"  required="true" aria-required="true">
                  </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <label class="col-sm-12">Email</label>
                  <div class="col-sm-12">
                  <div class="form-group">
                      <input class="form-control" name="email" id="input-email" type="text" placeholder="Email" value="<?php echo e($client ?  $client->email : old('email')); ?>" required="true"  required="true" aria-required="true">
                  </div>
                  </div>
                </div>
            </div>
            </div>
            <div class="card-footer text-right">
              <button type="submit" class="btn"><?php echo e($client->exists ? "Update Data" : "Add Item"); ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'ClientForm', 'titlePage' => __('Clients'),'pageSlug' => __('clients')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yogibagasd/algoseabiz/algoapp/resources/views/clients/form.blade.php ENDPATH**/ ?>