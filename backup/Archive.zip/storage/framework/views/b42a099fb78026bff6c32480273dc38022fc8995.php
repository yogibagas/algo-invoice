<?php $__env->startSection('content'); ?>
    <div class="header py-7 py-lg-8">
        <div class="container">
            <div class="header-body text-center mb-7">
                <div class="row justify-content-center">
                    <div class="col-lg-5 col-md-6">
                        <h1 class="text-white"><?php echo e(__('Hello ').$model->client->name); ?> !</h1>
                        <p class="text-lead text-light">
                            <?php echo e(__('Below are your invoice details')); ?>

                        </p>
                    </div>
                    
                </div>
            </div>
            <div class="col-12 mt-2">

                <div class="card px-4">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?php echo e(asset('black')); ?>/img/logo.png" class="img-fluid">
                            </div>
                            <div class="col-md-6 text-right">
                                <button class="btn  <?php echo e($model->status == "ONHOLD" ? "btn-danger" : "btn-primary"); ?>">Payment: <?php echo e($model->status); ?></button>
                            </div>
                        </div>
                        <div class="row mt-4">
                        <div class="col-sm-4">
                            
                            Invoice To: <strong><?php echo e($model->client->name); ?> - <?php echo e($model->client->pic_name); ?></strong><br>
                            No#: <strong><?php echo e($model->no_inv); ?></strong><br>
                        </div>
                            <div class="col-sm-4">
                                Created at: <strong><?php echo e(\Carbon\Carbon::parse($model->created_at)->format('d F Y')); ?></strong><br>
                                Due Date: <strong><?php echo e(\Carbon\Carbon::parse($model->due_date)->format('d F Y')); ?></strong>
                            </div>

                            <div class="col-sm-4">
                                Address: <strong><?php echo e($model->client->address); ?></strong><br>
                                Phone: <strong><?php echo e($model->client->phone); ?></strong>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table table-responsive">
                            <table class="table tablesorter " id="">
                                <thead class=" text-primary">
                                    <tr>
                                        <th scope="col" class="">No</th>
                                        <th scope="col">Item</th>
                                        <th scope="col">Rate</th>
                                        <th scope="col">Price (IDR)</th>
                                        <th scope="col">Qty</th>
                                        <th scope="col">Adjustment</th>
                                        <th scope="col">Total (IDR)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $model->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class=""><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($i->item_name); ?> <?php if($i->item_note): ?><br><small>(<?php echo e($i->item_note); ?>)</small><?php endif; ?></td>
                                            <td><?php echo e(ucwords(strtolower($i->qty_type))); ?></td>
                                            <td><?php echo e(number_format($i->price)); ?></td>
                                            <td><?php echo e(number_format($i->qty)); ?></td>
                                            <td><?php echo e(number_format($i->adjustment)); ?></td>
                                            <td><?php echo e(number_format($i->total)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tfoot>
                                        <tr class="bg-primary text-white">
                                            <td colspan="6 ml-3">Total : </td>
                                            <td><?php echo e(number_format($model->total)); ?></td>
                                        </tr>
                                        <tr>
                                        </tr>
                                    </tfoot>
                                </tbody>
                            </table>
                            <span class="text-white p-2">
                                <a href="#" class="text-info text-underline">Read our terms and condition</a> before you doing a payment
                            </span>
                        </div>
                    </div>
                </div>
                <form action="<?php echo e(route('payment.handler',$model->no_inv)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <h2 class="text-center">Select Your Payment below</h2>
                    <div class="row">
                    <div class="col-md-3 ">
                        <div class="selection-wrapper border border-white p-2 mb-3 bg-white ">
                            <label for="CC" class="selected-label">
                                <input type="radio" name="selected_item" value="CC" id="CC">
                                <span class="icon "></span>
                                <div class="selected-content text-dark text-center">
                                    <img src="<?php echo e(asset('black')); ?>/img/cc-logo.jpeg" class="img-fluid">
                                    <h4 class="text-dark">Visa/Mastercard</h4>
                                </div>
                            </label>
                        </div>
                        </div>
                    </div>
                    <button class="btn btn-primary">Pay </button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['pageSlug' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yogibagasd/algoseabiz/algoapp/resources/views/invoice/payment/index.blade.php ENDPATH**/ ?>